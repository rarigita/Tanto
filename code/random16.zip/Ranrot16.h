/* -------------------------- RANROT16.H -------------------------------
; random number generator by Agner Fog 1999
; 16-bit mode version for 80386/87, 80486, Pentium and compatible
; microprocessors including math processor.
; Works with DOS and Window 3.x.
;
; The code uses the RANROT type W algorithm without self-test.
; The resolution is 63 bits for WRandom and 32 bits for WBRandom.
;
; WRandomInit must be called before the first call to any of the random
; functions.
;
; WRandom returns a floating point number between 0 and 1.
; WBRandom returns an integer between 0 and 0xFFFFFFFF
;
; C++ prototypes:
;
; � 1999 Agner Fog. GNU General Public License www.gnu.org/copyleft/gpl.html
; -----------------------------------------------------------------------
*/

extern "C" void WRandomInit (long seed);
extern "C" double WRandom (void);
extern "C" unsigned long WBRandom (void);

