/**************************** RANMORO.CPP ******************* AgF 2001-11-11 *
*  The class TRandomMotRot encapsulates an assembly language random number   *
*  generator XRandom contained in the library RANDOMAO.LIB or RANDOMAC.LIB.  *
*                                                                            *
*  This random number generator is a combination of the Mother-of-all and    *
*  the RANROT-W generators. This may be used for the most demanding          *
*  applications.                                                             *
*                                                                            *
*  The class TRandomMotRot can have only one instance.                       *
*****************************************************************************/

#include "randoma.h"
#include "randomc.h"

TRandomMotRot::TRandomMotRot(uint32 seed) { // constructor
  static int instance = 0;
  assert(instance==0);            // make sure we have only one instance
  instance++;
  XRandomInit(seed);}             // initialize

